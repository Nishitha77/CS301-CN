Steps to run the application :

1. Open 2 Terminals in the directory in which the python files are present.

2. On one Terminal write the command "python3 server.py" to run the server side code.

3. To specify the port number that the server should run, command used is "python3 server.py -p 7777". (By default port no= 8000)

4. On other Terminal write the command "python3 client.py" to run the client side code.

5. By default the client knows that the server runs on 8000. If it is chamged then the command to run is "python3 client.py -p 7777",

6. "python3 client.py -n numberofTODOs" command to give number of TODOs. The default value of numberofTODOs is 3.

7. Now one by one enter the to-do's(strings) that you want to send to the server.

8. The server will send back the todos.