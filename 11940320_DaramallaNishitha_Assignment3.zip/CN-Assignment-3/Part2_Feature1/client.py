import argparse
import asyncio
import socket
from datetime import datetime


class UDPEchoClient:
    def __init__(self, address_info, num_todos, size):
        # Address Family - AF_INET - IPv4 , AF_INET6 - IPv6
        # SOCK_DGRAM - Socket Type - UDP
        self.client = socket.socket(address_info[0], socket.SOCK_DGRAM)
        self.num_todos = num_todos
        self.size = size

    def server_handler(self, server_socket):
     
        print(f"\n[PINGING] Pinging Server {server_socket}\n")
   
        for i in range(self.num_todos):
            message = input("Enter TODOs: ")
            self.client.sendto(message.encode("iso-8859-1"), server_socket)

            # Receive message from server
            response, server_socket = self.client.recvfrom(self.size)

            print(f"Task to-do num {i + 1} :'{response.decode('iso-8859-1').strip()}' \n")
        
        # Disconnecting Message
        print(f"[TERMINATION] Requesting Server {server_socket} for disconnection")
        self.client.sendto(("Disconnect").encode("iso-8859-1"), server_socket)
        response, server_socket = self.client.recvfrom(self.size)
        print(f"[TERMINATION] '{response.decode('iso-8859-1').strip()}' from {server_socket}")
   
        
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='UDP Echo Client',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('-i', '--ip', type=str, metavar="IP_ADDRESS/DOMAIN_NAME",
                        help='UDP Echo Server Local IP (IPv4 or IPv6) Address or Domain Name to Port Bind to',
                        default=socket.gethostbyname(socket.gethostname()))
    parser.add_argument('-p', '--port', type=int, metavar="PORT_NUMBER",
                        help='UDP Echo Server Port Number to connect to', default=8000)
    parser.add_argument('-n', '--num_todos', type=int,
                        help='Number of TO DOs', default=3)
    parser.add_argument('-s', '--size', type=int, metavar="SIZE",
                        help='MAX_SIZE', default=1024)
                 

    args = parser.parse_args()
    # Get IP for UDP
    address_info = socket.getaddrinfo(
        args.ip,
        args.port,
        proto=socket.IPPROTO_UDP
    )[0]

    client = UDPEchoClient(
        address_info=address_info,
        num_todos=args.num_todos,
        size=args.size
    )

    client.server_handler(server_socket=(
                    address_info[4][0],
                    address_info[4][1]))

