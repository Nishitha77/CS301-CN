import argparse
import socket


class UDPEchoServer:
    def __init__(self, address_info, size):
        self.server = None
        self.socket = (address_info[4][0], address_info[4][1])
        self.address_info = address_info
        self.size = size
        self.server_start()

    def server_start(self):
        # Address Family - AF_INET - IPv4 , AF_INET6 - IPv6
        # SOCK_DGRAM - Socket Type - UDP
        self.server = socket.socket(self.address_info[0], socket.SOCK_DGRAM)
        # Binding the socket to the port
        self.server.bind(self.socket)
        print(f'[SERVER INITIATED] UDP ECHO Server on {self.socket}')

    def client_handler(self):
        new_client = True
        while True:
            msg, client_socket = self.server.recvfrom(self.size)
            if new_client:
                print(f"[NEW CONNECTION] Client {client_socket} connected to server")
                new_client = False
            msg = msg.decode('iso-8859-1')
            print(f"[CLIENT'S MESSAGE] : '{msg.strip()}' \n")
            
            if msg.lower().strip() == "disconnect":
                    response = ("Disconnected")
                    print(f"[TERMINATION] - Client {client_socket} disconnected")
                    new_client = True    
            else:
              response = msg
            self.server.sendto(response.encode("iso-8859-1"), client_socket)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='UDP Echo Server',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('-i', '--ip', type=str, metavar="IP_ADDRESS/DOMAIN_NAME",
                        help='UDP Echo Server Local IP (IPv4 or IPv6) Address or Domain Name to Port Bind to',
                        default=socket.gethostbyname(socket.gethostname()))
    parser.add_argument('-p', '--port', type=int, metavar="PORT_NUMBER",
                        help='UDP Echo Server Port Number to Port Bind to', default=8000)
    parser.add_argument('-s', '--size', type=int, metavar="SIZE",
                        help='MAX_SIZE', default=1024)

    args = parser.parse_args()

    address_info = socket.getaddrinfo(
        args.ip,
        args.port,
        proto=socket.IPPROTO_UDP
    )[0]

    server = UDPEchoServer(address_info=address_info, size=args.size)
    server.client_handler()
