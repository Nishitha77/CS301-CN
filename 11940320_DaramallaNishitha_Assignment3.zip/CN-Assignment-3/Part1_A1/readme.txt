Steps to run the application :

1. Open 2 Terminals in the directory in which the python files are present.

2. In one Terminal write the command "python3 server.py" to run the server side code.

3. You can run the command "python3 server.py -p 7777". You can give any port number. By default port number is set 8000.

4. On other Terminal write the command "python3 ping.client.py" to run the client side code(The packet size, no of echo packets, time interval default values written in the code will be considered).

5. You can run the command "python3 ping.client.py -s 32 -n 4 -t 2". Here packet size is taken as 32 Bytes, number of echo messages are 4 and the time interval between 2 successive messages is 1 second.

6. Now one by one write the messages (strings) that you want to send to the server.

7. The server will send back the message.