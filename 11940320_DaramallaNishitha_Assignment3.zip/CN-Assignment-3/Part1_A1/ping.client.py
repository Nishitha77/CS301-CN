import argparse
import asyncio
import socket
from datetime import datetime


class UDPEchoClient:
    def __init__(self, pkt_size, address_info, interval, num_packets, message):
        # Address Family - AF_INET - IPv4 , AF_INET6 - IPv6
        # SOCK_DGRAM - Socket Type - UDP
        self.client = socket.socket(address_info[0], socket.SOCK_DGRAM)
        self.pkt_size = pkt_size #packet size
        self.interval = interval
        self.num_packets = num_packets
        self.message = self.get_padded_message(message)

    async def server_handler(self, server_socket):
        rtt_values = []
        num_received = 0
        total_time = 0.0
        time_start = datetime.now()
        print(f"\n[PINGING] Pinging Server {server_socket} : bytes = {self.pkt_size}")
        #if the packet size is changed this if block dislays a message in the terminal
        if self.pkt_size != 64:
            print(f"[PACKET SIZE] Requesting Server {server_socket} for changing packet size to {self.pkt_size}")
            message = self.get_padded_message(f"Size {self.pkt_size}")
            self.client.sendto(message.encode("iso-8859-1"), server_socket)
            # Receive message from server
            response, server_socket = self.client.recvfrom(self.pkt_size)
            print(f"[PACKET SIZE] '{response.decode('iso-8859-1').strip()}' from {server_socket}")
        await asyncio.sleep(0)

        for packet in range(self.num_packets):
            message = input("Enter something to send to the server: ")
            self.message = self.get_padded_message(message)
            before_request = datetime.now() 
            self.client.sendto(self.message.encode("iso-8859-1"), server_socket)

            # Timeout Exception Handling 
            try:
                # Receive message from server
                response, server_socket = self.client.recvfrom(self.pkt_size)
            except socket.timeout:
                print("[PACKET LOSS] Sending Next Packet")
                continue

            after_response = datetime.now()
            rtt_time = (after_response - before_request).total_seconds() * 1000
            rtt_values.append(rtt_time)

            print(f"[MESSAGE RECEIVED] '{response.decode('iso-8859-1').strip()}' from {server_socket} : "
                  f"bytes = {len(response)} rtt = {round(rtt_time, 4)} ms")
            num_received += 1
            await asyncio.sleep(self.interval)

        # Disconnecting Message
        print(f"[TERMINATION] Requesting Server {server_socket} for disconnection")
        self.client.sendto(self.get_padded_message("Disconnect").encode("iso-8859-1"), server_socket)
        response, server_socket = self.client.recvfrom(self.pkt_size)
        print(f"[TERMINATION] '{response.decode('iso-8859-1').strip()}' from {server_socket} : bytes = {len(response)}")
        time_end = datetime.now()
        total_time = (time_end - time_start).total_seconds() * 1000
        
        print()
        self.print_statistics(num_received, server_socket, total_time)
        
    def get_padded_message(self, message):
        message = message.encode("iso-8859-1")
        if len(message) < self.pkt_size:
            message += b' ' * (self.pkt_size - len(message))
        return message.decode("iso-8859-1")
    
    def print_statistics(self, num_received, server_socket, total_time):
        print(f"\n===={server_socket}: ping statistics====\n")
        print(f"Packets sent: {self.num_packets + 1}, Packets received: {num_received + 1},\n"
          f"Lost {self.num_packets - num_received} ({self.get_loss_percentage(num_received)}% Loss)\n"
          f"Total time: {round(total_time, 5)}ms \n") 
      
    def get_loss_percentage(self, num_received):
        return round(((self.num_packets - num_received) / self.num_packets * 100), 4)
 

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='UDP Echo Client',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('-i', '--ip', type=str, metavar="IP_ADDRESS/DOMAIN_NAME",
                        help='UDP Echo Server Local IP (IPv4 or IPv6) Address or Domain Name to Port Bind to',
                        default=socket.gethostbyname(socket.gethostname()))
    parser.add_argument('-p', '--port', type=int, metavar="PORT_NUMBER",
                        help='UDP Echo Server Port Number to connect to', default=8000)
    parser.add_argument('-m', '--message', type=str,
                        help='UDP Echo Message to send', default="Hello Server")
    parser.add_argument('-n', '--num_packets', type=int,
                        help='Number of UDP Echo Packets to send', default=5)
    parser.add_argument('-s', '--size', type=int, metavar="PKT_SIZE",
                        help='UDP Echo Packet Size in Bytes', default=64)
    parser.add_argument('-t', '--interval', type=float, metavar="TIME",
                        help='UDP Echo Message Interval in sec', default=1)
                        

    args = parser.parse_args()
    # Get IP for UDP
    address_info = socket.getaddrinfo(
        args.ip,
        args.port,
        proto=socket.IPPROTO_UDP
    )[0]

    client = UDPEchoClient(
        pkt_size=args.size,
        address_info=address_info,
        interval=args.interval,
        message=args.message,
        num_packets=args.num_packets,
    )

    loop = asyncio.get_event_loop()

    loop.run_until_complete(
        asyncio.gather(
            client.server_handler(
                server_socket=(
                    address_info[4][0],
                    address_info[4][1]))
        )
    )

